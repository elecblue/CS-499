"""
Module Name: aac_crud.py
Author: Nik Myers
Course: CS-340-11283
Assignment: 5-1 Project One (AAC-CRUD module)
Instructor: Robert Kayl
Date: 2025-03-31
Version: 1.0-beta
Description: This module provides a CRUD class to interact with a MongoDB database.
"""
from typing import Optional, Any

from pymongo import MongoClient, UpdateMany
from pymongo.results import *
from pymongo.results import _WriteResult


class CRUD:
    """
    A portable CRUD class to interact with a MongoDB database.
    """

    def __init__(self, username, password, host='localhost', port=27017, authdb='admin'):
        """
        Initializes the MongoDB client.

        Args:
            username (str): Username for authentication.
            password (str): Password for authentication.
            host (str): MongoDB host address. Default is 'localhost'.
            port (int): MongoDB port. Default is 27017.
            authdb (str): Database to use for authentication. Default is 'admin'.
        """

        try:
            # Establish connection to MongoDB using provided credentials
            self.client: MongoClient = MongoClient(host=host, port=port,
                                                   username=username,
                                                   password=password,
                                                   authSource=authdb)
            print(f"[aac_crud]: Connected to {host}:{port} successfully!", end="\n\n")
        except Exception as e:
            print(f"[aac_crud]: Error connecting to MongoDB on {host}:{port}: ", e, end="\n\n")

    def insert_document(self, db_name, collection_name, document) -> bool:
        """
        Inserts a document into the specified MongoDB database and collection.

        Args:
            db_name (str): The name of the database.
            collection_name (str): The name of the collection.
            document (dict): The document to be inserted.

        Returns:
            bool: True if the insert is successful; otherwise, False.
        """

        # Verify connection and attempt to insert the document
        if not self.client:
            print("[aac_crud]: No MongoDB connection available.", end="\n\n")
            return False
        try:
            db = self.client[db_name]
            collection = db[collection_name]
            result = collection.insert_one(document)
            return result.acknowledged
        except Exception as e:
            print("[aac_crud]: Error inserting document:\t", e, end="\n\n")
            return False

    def find_documents(self, db_name, collection_name, query) -> list:
        """
        Queries for documents in the specified MongoDB database and collection.

        Args:
            db_name (str): The name of the database.
            collection_name (str): The name of the collection.
            query (dict): Key/value lookup pair(s) for the query.

        Returns:
            list: A list of documents that match the query; returns an empty list if an error occurs.
        """

        # Verify connection and attempt to find documents
        if not self.client:
            print("[aac_crud]: No MongoDB connection available.", end="\n\n")
            return []
        try:
            db = self.client[db_name]
            collection = db[collection_name]
            # Use find() to get a cursor and convert it to a list
            documents = list(collection.find(query))
            return documents
        except Exception as e:
            print("[aac_crud]: Error finding documents:\t", e, end="\n\n")
            return []

    def update_document(self, db_name, collection_name, query, update) -> int:
        """
        Updates a document in the specified MongoDB database and collection.

        Args:
            db_name (str): The name of the database.
            collection_name (str): The name of the collection.
            query (dict): Key/value lookup pair(s) for the query.
            update (dict): The update to be applied.

        Returns:
            int: True if the update is successful; otherwise, False.
        """

        # Verify connection and attempt to update the document
        if not self.client:
            print("[aac_crud]: No MongoDB connection available.", end="\n\n")
            return 0
        try:
            db = self.client[db_name]
            collection = db[collection_name]
            result = collection.update_many(query, {'$set': update})
            return result.modified_count
        except Exception as e:
            print("[aac_crud]: Error updating document:\t", e, end="\n\n")
            pass

        return 0

    def delete_document(self, db_name, collection_name, query) -> int:
        """
        Deletes a document from the specified MongoDB database and collection.

        Args:
            db_name (str): The name of the database.
            collection_name (str): The name of the collection.
            query (dict): Key/value lookup pair(s) for the query.

        Returns:
            bool: True if the delete attempt is successful; otherwise, False.
        """

        # Verify connection and attempt to delete the document
        if not self.client:
            print("[aac_crud]: No MongoDB connection available.", end="\n\n")
            return 0
        try:
            db = self.client[db_name]
            collection = db[collection_name]
            result = collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            print("[aac_crud]: Error deleting document:\t", e, end="\n\n")
            return 0
